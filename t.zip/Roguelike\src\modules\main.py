import classes
import glsl

class MainMenu(classes.Scene):
    def onSceneChange(self, other):
        ...

    def __init__(self):
        self.name = "MainMenuScene"
        

    def update(self, g):
        ...

    def draw(self, g):
        ...



def setup(g):
    g.currentScene = "MainMenuScene"
    g.scenes["MainMenuScene"] = MainMenu()
