from ast import Global
import pygame
from win32api import GetSystemMetrics
from pygame.locals import *

import importlib
import os
import classes
import glsl

windowSize = (1280, 720)
screenSize = (800, 600)

class Globals:
    display = pygame.display.set_mode(windowSize)
    screen = pygame.Surface(screenSize)
    camera = [0, 0, 0]
    currentScene = ""
    entityMap = {}
    entities = []    
    chunks = []
    scenes = {}
    updates = []
    draws = []

def loadModules(dir, name):
    for file in os.listdir(dir):
        if (os.path.isfile(dir + "/" + file)):
            mod = importlib.import_module(name + "." + file[:-3])
            mod.setup(Globals) # weird

loadModules("src/modules", "modules")
print(Globals.currentScene)
pygame.init()
glsl.init()

running = True

FPS = pygame.time.Clock()

while (running):
    for event in pygame.event.get():
        if (event.type == QUIT):
            running = False
    
    Globals.display.fill((0, 0, 0))
    Globals.screen.fill((0, 0, 0))
    
    Globals.scenes[Globals.currentScene].update(Globals)

    for func in Globals.updates:
        func(Globals)

    Globals.scenes[Globals.currentScene].draw(Globals)

    for func in Globals.draws:
        func(Globals)

    Globals.display.blit(pygame.transform.scale(Globals.screen, windowSize), (0, 0))

    pygame.display.update()
    FPS.tick(60)
