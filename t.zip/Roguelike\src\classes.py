class Entity:
    def __init__(self):
        self.position = [0, 0, 0]

    def update(self, globals):
        ...

    def draw(self, globals):
        ...

    def getInstance(self):
        return Entity()

class Scene:
    name: str
    def onSceneChange(self, other):
        ...

    def __init__(self):
        ...

    def update(self, globals):
        ...

    def draw(self, globals):
        ...