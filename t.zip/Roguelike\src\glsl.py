from OpenGL.GL import *
from OpenGL.GL.shaders import *
from pygame.locals import *
import pygame, numpy, sys, glfw

pygame.init()
if not glfw.init():
    sys.exit()

def getFileContent(file):
    with open(file, 'r') as file:
        content = file.read()
    return content

def quit():
    global glfwwindow
    glfw.destroy_window(glfwwindow)

# Create a glfw window
# It's size will be edited later
def init():
    global width, height, glfwwindow
    width, height = 1, 1
    glfw.window_hint(glfw.VISIBLE, False)
    glfwwindow = glfw.create_window(width, height, "", None, None)
    glfw.make_context_current(glfwwindow)
    glViewport(0, 0, width, height)

# Do as much as possible before using the shader
# Ouput an array of data, which will not change over time
def create(vertexShaderPath, fragmentShaderPath):
    global timeMessage
    vertices = numpy.array((0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0), dtype=numpy.float32)
    texcoords = numpy.array((-1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0), dtype=numpy.float32)
    texcoords = numpy.array((-1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0), dtype=numpy.float32)
    vertexShader = compileShader(getFileContent(vertexShaderPath), GL_VERTEX_SHADER)
    fragmentShader = compileShader(getFileContent(fragmentShaderPath), GL_FRAGMENT_SHADER)
    shader = (vertices, texcoords, vertexShader, fragmentShader)
    return shader

# You need to create a shader first
# Give optional variables that can be used by the GLSL shader
def apply(shader, image, **variables):
    vertices, texcoords, vertexShader, fragmentShader = shader
    global glfwwindow, timeMessage
    width, height = image.get_size()

    glfw.set_window_size(glfwwindow, width, height)
    glViewport(0, 0, width, height)
    glClear(GL_COLOR_BUFFER_BIT)

    textureData = pygame.image.tostring(image, "RGB", 1)
    glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, textureData)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)

    shaderProgram = glCreateProgram()
    glAttachShader(shaderProgram, vertexShader)
    glAttachShader(shaderProgram, fragmentShader)
    glLinkProgram(shaderProgram)

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, vertices)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, texcoords)
    glEnableVertexAttribArray(0)
    glEnableVertexAttribArray(1)
    glFlush()
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)

    glUseProgram(shaderProgram)

    # Send variables to the shader if provided
    for variable in variables:
        location = glGetUniformLocation(shaderProgram, variable)
        glUniform1f(location, variables[variable])
    glDrawArrays(GL_QUADS, 0, 4)

    # Turn image to pygame surface
    data = glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE)
    return pygame.transform.flip(pygame.image.frombuffer(data, (width, height), "RGBA"), False, True)